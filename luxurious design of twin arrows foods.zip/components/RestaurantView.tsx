import React, { useState, useEffect, useRef } from 'react';
import { RestaurantData, MenuItem } from '../types';
import { Phone, MapPin, Clock, Star, Share2, ArrowLeft, Heart, Navigation, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

interface RestaurantViewProps {
  data: RestaurantData;
  onBack: () => void;
}

export const RestaurantView: React.FC<RestaurantViewProps> = ({ data, onBack }) => {
  const { theme } = data;
  const [activeTab, setActiveTab] = useState<'menu' | 'details'>('menu');
  const [scrolled, setScrolled] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Scroll listener for navbar transparency effect
  useEffect(() => {
    const handleScroll = () => {
      if (scrollRef.current) {
        setScrolled(scrollRef.current.scrollTop > 50);
      }
    };
    const ref = scrollRef.current;
    if (ref) ref.addEventListener('scroll', handleScroll);
    return () => ref?.removeEventListener('scroll', handleScroll);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % data.images.gallery.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + data.images.gallery.length) % data.images.gallery.length);
  };

  const menuItems: Record<string, MenuItem[]> = {
    'lazyPanda': [
      {
        name: 'Panda Special Momos',
        price: '₹169',
        description: 'Signature steamed dumplings with secret chef filling',
        isPopular: true,
        image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=600&q=80'
      },
      {
        name: 'Schezwan Chicken Momos',
        price: '₹139',
        description: 'Spicy chicken filling served with schezwan dip',
        image: 'https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?auto=format&fit=crop&w=600&q=80'
      },
      {
        name: 'Corn & Cheese Momos',
        price: '₹139',
        description: 'Melting cheese and sweet corn kernels',
        image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=600&q=80'
      },
      {
        name: 'Chicken Fried Momos',
        price: '₹139',
        description: 'Crispy fried dumplings with juicy chicken',
        image: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?auto=format&fit=crop&w=600&q=80'
      },
      { 
        name: 'Honey Chicken', 
        price: '₹280', 
        description: 'Crispy chicken tossed in sweet honey glaze', 
        isPopular: true,
        image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Schezwan Fried Rice', 
        price: '₹220', 
        description: 'Spicy rice with fresh vegetables',
        image: 'https://images.unsplash.com/photo-1603133872878-684f10842740?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Panda Special Noodles', 
        price: '₹250', 
        description: 'Chef special indo-chinese blend',
        image: 'https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=600&q=80' 
      }
    ],
    'grillEmpire': [
      { 
        name: 'Classic Shawarma Roll', 
        price: '₹110', 
        description: 'Authentic spiced chicken wrapped in soft kuboos', 
        image: 'https://images.unsplash.com/photo-1619860860774-1e2e17343432?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Peri Peri Shawarma', 
        price: '₹130', 
        description: 'Spicy peri peri sauce with juicy grilled chicken',
        isPopular: true,
        image: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Mexican Plate Shawarma', 
        price: '₹170', 
        description: 'Open plate served with salad, mayo and spicy salsa',
        image: 'https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Pepper Grill Chicken (Half)', 
        price: '₹220', 
        description: 'Charcoal grilled with crushed black pepper',
        image: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Smokey BBQ Chicken', 
        price: '₹230', 
        description: 'Glazed in rich hickory smoke BBQ sauce',
        image: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?auto=format&fit=crop&w=600&q=80' 
      },
      { 
        name: 'Tandoori Kebab Platter', 
        price: '₹250', 
        description: 'Assorted chicken kebabs with mint chutney',
        image: 'https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=600&q=80' 
      }
    ],
    'fruitzilla': [
      { 
        name: 'Watermelon Crush', 
        price: '₹80', 
        description: 'Pure watermelon juice with a hint of mint', 
        isPopular: true,
        image: 'https://images.unsplash.com/photo-1589733955941-5eeaf752f6dd?auto=format&fit=crop&w=600&q=80'
      },
      { 
        name: 'Dragon Fruit Smoothie', 
        price: '₹150', 
        description: 'Exotic blend with yogurt and honey',
        image: 'https://images.unsplash.com/photo-1623065422902-30a2d299bbe4?auto=format&fit=crop&w=600&q=80'
      },
      { 
        name: 'Mixed Fruit Bowl', 
        price: '₹120', 
        description: 'Seasonal cut fruits topped with nuts',
        image: 'https://images.unsplash.com/photo-1511690656952-34342d5c2895?auto=format&fit=crop&w=600&q=80'
      },
      { 
        name: 'ABC Juice', 
        price: '₹100', 
        description: 'Apple, Beetroot, Carrot detox blend',
        image: 'https://images.unsplash.com/photo-1543339308-43e59d6b73a6?auto=format&fit=crop&w=600&q=80'
      }
    ]
  };

  return (
    <div className={`h-screen w-full overflow-hidden relative ${theme.background} text-white`}>
      
      {/* Navbar - Absolute & Transparent */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-black/80 backdrop-blur-md py-3 shadow-lg' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 group text-white/90 hover:text-white transition-colors focus:outline-none"
          >
            <div className="p-2 bg-white/10 rounded-full backdrop-blur-sm group-hover:bg-white/20 group-hover:scale-110 active:scale-95 transition-all duration-300 ease-out shadow-[0_0_15px_rgba(0,0,0,0.2)]">
                <ArrowLeft size={18} />
            </div>
            <span className={`text-sm tracking-widest uppercase font-medium opacity-0 group-hover:opacity-100 transition-all -translate-x-2 group-hover:translate-x-0 duration-300 ${scrolled ? 'hidden md:block' : ''}`}>Back</span>
          </button>
          
          <div className="flex gap-4">
            <button className="p-2 bg-white/10 rounded-full backdrop-blur-sm hover:bg-white/20 hover:scale-110 active:scale-95 transition-all duration-300 ease-out shadow-[0_0_15px_rgba(0,0,0,0.2)]"><Heart size={18} /></button>
            <button className="p-2 bg-white/10 rounded-full backdrop-blur-sm hover:bg-white/20 hover:scale-110 active:scale-95 transition-all duration-300 ease-out shadow-[0_0_15px_rgba(0,0,0,0.2)]"><Share2 size={18} /></button>
          </div>
        </div>
      </nav>

      {/* Main Scroll Container */}
      <div ref={scrollRef} className="h-full overflow-y-auto overflow-x-hidden scroll-smooth scrollbar-hide perspective-1000">
        
        {/* Parallax Hero Section */}
        <div className="relative h-[75vh] w-full flex items-end justify-center pb-24 group">
            <div 
                className="absolute inset-0 bg-cover bg-center z-0 transition-transform duration-[20s] ease-linear group-hover:scale-105"
                style={{ backgroundImage: `url(${data.images.hero})`, backgroundAttachment: 'fixed' }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />
            
            <div className="relative z-20 text-center px-4 animate-slideUp">
                <span className="block text-gold-400 tracking-[0.4em] text-xs uppercase mb-4 drop-shadow-md">{data.tagline}</span>
                <h1 className="text-5xl md:text-7xl font-serif font-medium text-white mb-6 drop-shadow-2xl">{data.name}</h1>
                <div className="flex items-center justify-center gap-4 text-sm font-light tracking-wide text-white/80">
                    <span className="flex items-center gap-1"><Star size={14} className="text-gold-400 fill-current" /> {data.rating}</span>
                    <span>•</span>
                    <span>{data.type}</span>
                    <span>•</span>
                    <span>{data.priceRange}</span>
                </div>
            </div>

            <div className="absolute bottom-8 left-0 right-0 flex justify-center z-20 animate-bounce opacity-50">
                <ChevronDown size={24} />
            </div>
        </div>

        {/* Floating Content Sheet */}
        <div className={`relative z-30 -mt-10 min-h-screen ${theme.cardBg} rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.5)] border-t border-white/5`}>
            
            {/* Sticky Tabs */}
            <div className="sticky top-0 z-40 backdrop-blur-xl bg-black/40 border-b border-white/5 rounded-t-[3rem] px-6 transition-all duration-300">
                <div className="flex justify-center max-w-md mx-auto">
                    {['menu', 'details'].map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab as any)}
                            className={`flex-1 py-6 text-xs uppercase tracking-[0.2em] transition-all duration-300 relative group outline-none ${
                                activeTab === tab ? 'text-white font-semibold' : 'text-white/40 hover:text-white'
                            }`}
                        >
                            <span className="relative z-10">{tab}</span>
                            {activeTab === tab && (
                                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-gold-400 shadow-[0_0_10px_#D4AF37] transition-all duration-300" />
                            )}
                            {/* Hover underline for inactive tabs */}
                            {activeTab !== tab && (
                                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-0 h-px bg-white/30 group-hover:w-4 transition-all duration-300" />
                            )}
                        </button>
                    ))}
                </div>
            </div>

            <div className="max-w-3xl mx-auto p-6 md:p-10 pb-24">
                
                {/* MENU TAB */}
                {activeTab === 'menu' && (
                    <div className="space-y-8 animate-fadeIn">
                        <div className="text-center mb-10">
                            <h3 className="font-serif text-3xl italic text-white/90">Signature Selections</h3>
                            <div className="w-16 h-px bg-gold-400 mx-auto mt-4 opacity-70"></div>
                        </div>

                        <div className="grid gap-6">
                            {menuItems[data.id] && menuItems[data.id].map((item, idx) => (
                                <div 
                                    key={idx} 
                                    className="group relative flex flex-col md:flex-row gap-6 items-start md:items-center p-4 -mx-4 rounded-2xl hover:bg-white/5 transition-all duration-500 border border-transparent hover:border-white/5 hover:shadow-xl cursor-default"
                                    style={{ animationDelay: `${idx * 0.1}s` }}
                                >
                                    <div className="w-full md:w-48 h-48 overflow-hidden rounded-xl shadow-lg shrink-0 relative">
                                        <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-500 z-10" />
                                        <img 
                                            src={item.image} 
                                            alt={item.name} 
                                            className="w-full h-full object-cover transform scale-100 group-hover:scale-110 transition-transform duration-700 ease-in-out grayscale-[20%] group-hover:grayscale-0"
                                        />
                                    </div>
                                    <div className="flex-1 w-full relative">
                                        <div className="flex justify-between items-baseline border-b border-white/10 pb-2 mb-3 group-hover:border-white/30 transition-colors duration-500">
                                            <h4 className="text-xl font-serif font-medium text-white/90 group-hover:text-white transition-colors">{item.name}</h4>
                                            <span className="text-lg font-serif text-gold-400 group-hover:scale-110 origin-right transition-transform duration-300">{item.price}</span>
                                        </div>
                                        <p className="text-sm text-white/60 font-light leading-relaxed mb-3 group-hover:text-white/80 transition-colors duration-300">{item.description}</p>
                                        {item.isPopular && (
                                            <span className="inline-block text-[10px] uppercase tracking-widest text-black bg-gold-400 px-2 py-1 font-bold shadow-[0_0_10px_rgba(212,175,55,0.4)]">Chef's Choice</span>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                        
                        <div className="mt-12 p-8 border border-white/5 bg-white/5 rounded-none text-center hover:bg-white/10 transition-colors duration-500">
                            <p className="font-serif italic text-white/60">" Great food is an emotion, not just a meal. "</p>
                        </div>
                    </div>
                )}

                {/* DETAILS TAB */}
                {activeTab === 'details' && (
                    <div className="space-y-8 animate-fadeIn text-center md:text-left">
                         {/* Owner Msg */}
                         {data.ownerMessage && (
                            <div className="bg-gradient-to-br from-white/10 to-transparent p-8 border border-white/5 relative overflow-hidden group hover:border-white/20 transition-all duration-500">
                                <div className="absolute top-0 right-0 -mr-4 -mt-4 w-20 h-20 bg-gold-400 blur-[50px] opacity-20 group-hover:opacity-30 transition-opacity duration-500"></div>
                                <h4 className="font-serif text-2xl mb-4 italic text-gold-400 group-hover:translate-x-1 transition-transform duration-300">A Note from the Kitchen</h4>
                                <p className="text-white/80 leading-relaxed font-light mb-4">"{data.ownerMessage.text}"</p>
                                <p className="text-xs uppercase tracking-widest text-white/40">{data.ownerMessage.date}</p>
                            </div>
                         )}

                         <div className="grid md:grid-cols-2 gap-8">
                             <div className="space-y-4">
                                <div className="space-y-4">
                                  <InfoBlock icon={<Clock size={20} />} title="Opening Hours" text={data.hours} sub={data.isOpen ? 'Open Now' : 'Closed'} active={data.isOpen} />
                                  <InfoBlock icon={<MapPin size={20} />} title="Location" text={data.address} />
                                  {/* Map Preview Image */}
                                  <div className="w-full h-32 rounded-lg overflow-hidden border border-white/10 hover:border-white/30 transition-all cursor-pointer group/map relative ml-11 mt-2">
                                     <img 
                                        src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=600&q=80" 
                                        alt="Map Preview" 
                                        className="w-full h-full object-cover opacity-60 group-hover/map:opacity-80 transition-opacity"
                                     />
                                     <div className="absolute inset-0 flex items-center justify-center bg-black/30 group-hover/map:bg-transparent transition-colors">
                                        <span className="px-3 py-1 bg-black/60 backdrop-blur-sm text-[10px] uppercase tracking-widest text-white/80 border border-white/10">View on Map</span>
                                     </div>
                                  </div>
                                  <InfoBlock icon={<Phone size={20} />} title="Contact" text={data.phone || ''} isLink />
                                </div>
                             </div>
                             
                             <div className="bg-white/5 p-6 border border-white/5 h-full relative group min-h-[300px] flex flex-col hover:border-white/20 transition-all duration-500">
                                 <h4 className="font-serif text-xl mb-6 flex items-center gap-2">
                                     Gallery
                                     <span className="h-px flex-1 bg-white/10 group-hover:bg-white/30 transition-colors"></span>
                                 </h4>
                                 <div className="relative flex-1 w-full overflow-hidden rounded-lg bg-black/50 shadow-2xl">
                                     {/* Images Carousel */}
                                     {data.images.gallery.map((img, index) => (
                                         <div
                                            key={index}
                                            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'}`}
                                         >
                                            <img src={img} className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-[10s]" alt={`Gallery Image ${index + 1}`} />
                                            {/* Gradient Overlay for Controls visibility */}
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-60"></div>
                                         </div>
                                     ))}

                                     {/* Navigation Controls */}
                                     <button
                                        onClick={(e) => { e.stopPropagation(); prevSlide(); }}
                                        className="absolute left-2 top-1/2 -translate-y-1/2 p-3 bg-black/20 hover:bg-gold-500 text-white rounded-full backdrop-blur-md transition-all duration-300 opacity-0 group-hover:opacity-100 z-20 hover:scale-110 -translate-x-4 group-hover:translate-x-0"
                                     >
                                        <ChevronLeft size={20} />
                                     </button>
                                     <button
                                        onClick={(e) => { e.stopPropagation(); nextSlide(); }}
                                        className="absolute right-2 top-1/2 -translate-y-1/2 p-3 bg-black/20 hover:bg-gold-500 text-white rounded-full backdrop-blur-md transition-all duration-300 opacity-0 group-hover:opacity-100 z-20 hover:scale-110 translate-x-4 group-hover:translate-x-0"
                                     >
                                        <ChevronRight size={20} />
                                     </button>

                                     {/* Indicators */}
                                     <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 z-20">
                                        {data.images.gallery.map((_, idx) => (
                                            <button
                                                key={idx}
                                                onClick={() => setCurrentSlide(idx)}
                                                className={`h-1 rounded-full transition-all duration-500 ${idx === currentSlide ? 'bg-gold-400 w-8 shadow-[0_0_10px_#D4AF37]' : 'bg-white/40 w-2 hover:bg-white'}`}
                                            />
                                        ))}
                                     </div>
                                 </div>
                             </div>
                         </div>
                    </div>
                )}
            </div>
            
            {/* Bottom Action Bar */}
            <div className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-xl border-t border-white/10 p-4 z-50 md:hidden">
                <div className="grid grid-cols-2 gap-4">
                    <button className="flex items-center justify-center gap-2 bg-white text-black py-3 px-4 font-bold uppercase tracking-wider text-xs transform active:scale-95 transition-all duration-300 hover:bg-gray-200">
                        <Navigation size={16} /> Navigate
                    </button>
                    <button className="flex items-center justify-center gap-2 bg-gold-500 text-black py-3 px-4 font-bold uppercase tracking-wider text-xs transform active:scale-95 transition-all duration-300 hover:bg-gold-400 shadow-[0_0_15px_rgba(212,175,55,0.3)]">
                        <Phone size={16} /> Call Now
                    </button>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};

const InfoBlock = ({ icon, title, text, sub, active, isLink }: any) => (
    <div className={`group flex items-start gap-4 p-4 border-b border-white/5 hover:bg-white/5 transition-all duration-300 ${isLink ? 'cursor-pointer' : 'cursor-default'}`}>
        <div className="text-gold-400 mt-1 transition-transform duration-300 group-hover:scale-110 group-hover:text-gold-300 shadow-gold-500/50 drop-shadow-sm">{icon}</div>
        <div className="transition-transform duration-300 group-hover:translate-x-2">
            <p className="text-xs uppercase tracking-widest text-white/50 mb-1 group-hover:text-white/70 transition-colors">{title}</p>
            <p className={`text-sm md:text-base ${isLink ? 'underline underline-offset-4 decoration-white/30 group-hover:decoration-gold-400' : ''}`}>{text}</p>
            {sub && <p className={`text-xs font-bold mt-1 ${active ? 'text-green-400' : 'text-red-400'}`}>{sub}</p>}
        </div>
    </div>
);