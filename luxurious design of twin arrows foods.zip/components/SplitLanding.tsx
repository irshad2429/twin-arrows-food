import React from 'react';
import { LAZY_PANDA_DATA, GRILL_EMPIRE_DATA, FRUITZILLA_DATA } from '../constants';
import { ArrowRight } from 'lucide-react';

interface SplitLandingProps {
  onSelect: (id: 'lazyPanda' | 'grillEmpire' | 'fruitzilla') => void;
}

const BrandTitle = ({ name, subtitle, colorClass }: { name: string, subtitle: string, colorClass: string }) => (
  <div className="text-center z-10 p-6 transition-all duration-500 transform group-hover:-translate-y-4">
    <p className="text-xs md:text-sm uppercase tracking-[0.3em] text-white/80 mb-3 animate-fadeIn">{subtitle}</p>
    <h2 className="text-4xl md:text-6xl font-serif font-bold text-white mb-6 drop-shadow-2xl">{name}</h2>
    <div className={`inline-flex items-center gap-2 px-6 py-3 border border-white/30 backdrop-blur-sm rounded-none text-white text-sm tracking-widest uppercase hover:bg-white hover:text-black transition-all duration-300 opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0`}>
      <span>Discover</span>
      <ArrowRight size={14} />
    </div>
  </div>
);

export const SplitLanding: React.FC<SplitLandingProps> = ({ onSelect }) => {
  return (
    <div className="relative flex flex-col lg:flex-row h-screen w-full bg-black overflow-hidden">
      
      {/* Header Overlay */}
      <div className="absolute top-0 w-full z-50 py-6 text-center pointer-events-none mix-blend-difference">
        <h1 className="text-white font-serif italic text-2xl tracking-widest opacity-90">Twin Arrows Foods</h1>
        <div className="w-12 h-px bg-white mx-auto mt-2 opacity-50"></div>
      </div>

      {/* Lazy Panda */}
      <div 
        className="relative group flex-1 h-1/3 lg:h-full cursor-pointer overflow-hidden border-b lg:border-b-0 lg:border-r border-white/10 transition-all duration-700 ease-in-out hover:flex-[1.5]"
        onClick={() => onSelect('lazyPanda')}
      >
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-all duration-700 z-10" />
        <div 
            className="absolute inset-0 bg-cover bg-center animate-slowZoom"
            style={{ backgroundImage: `url(${LAZY_PANDA_DATA.images.hero})` }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
            <BrandTitle name="Lazy Panda" subtitle="Indo-Chinese Cuisine" colorClass="text-red-500" />
        </div>
      </div>

      {/* Grill Empire */}
      <div 
        className="relative group flex-1 h-1/3 lg:h-full cursor-pointer overflow-hidden border-b lg:border-b-0 lg:border-r border-white/10 transition-all duration-700 ease-in-out hover:flex-[1.5]"
        onClick={() => onSelect('grillEmpire')}
      >
        <div className="absolute inset-0 bg-black/50 group-hover:bg-black/20 transition-all duration-700 z-10" />
        <div 
            className="absolute inset-0 bg-cover bg-center animate-slowZoom"
            style={{ backgroundImage: `url(${GRILL_EMPIRE_DATA.images.hero})`, animationDelay: '-5s' }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
             <BrandTitle name="Grill Empire" subtitle="The Art of Shawarma" colorClass="text-orange-500" />
        </div>
      </div>

      {/* Fruitzilla */}
      <div 
        className="relative group flex-1 h-1/3 lg:h-full cursor-pointer overflow-hidden transition-all duration-700 ease-in-out hover:flex-[1.5]"
        onClick={() => onSelect('fruitzilla')}
      >
        <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-all duration-700 z-10" />
        <div 
            className="absolute inset-0 bg-cover bg-center animate-slowZoom"
            style={{ backgroundImage: `url(${FRUITZILLA_DATA.images.hero})`, animationDelay: '-10s' }}
        />
        <div className="absolute inset-0 flex items-center justify-center">
            <BrandTitle name="Fruitzilla" subtitle="Exotic Refreshments" colorClass="text-emerald-500" />
        </div>
      </div>

      <div className="absolute bottom-6 w-full text-center z-50 pointer-events-none">
         <p className="text-white/50 text-[10px] tracking-[0.5em] uppercase">Select a Destination</p>
      </div>
    </div>
  );
};